package Vehiculo;

public class Motor {

    private int potencia;

    private int revolucionesMaximas;

    public Motor(int potencia, int revolucionesMaximas) {

        this.potencia = potencia;


        this.revolucionesMaximas = revolucionesMaximas;
    }

    public int getPotencia() {
        return potencia;
    }

    public int getRevolucionesMaximas() {
        return revolucionesMaximas;
    }

    public int calcularRevoluciones(int fuerza, int radio) {

        if (fuerza <= 0 || radio <= 0) {

            throw new IllegalArgumentException("fuerza y radio >>0");
        }

        return (int) ((1000.0 * fuerza) / (Math.PI * radio));
    }
}
