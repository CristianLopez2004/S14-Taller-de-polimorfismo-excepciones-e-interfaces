package Vehiculo;

public class Acuatico extends Vehiculo {

    private Motor motor;

    private Vela vela;


    public Acuatico(int velocidadActual, int velocidadMaxima, Motor motor, Vela vela) {
        super(velocidadActual, velocidadMaxima);


        this.motor = motor;

        this.vela = vela;
    }

    @Override

    public void acelerar(int velocidad) {


        super.acelerar(velocidad);
    }

    @Override
    public void frenar(int velocidad) {

        super.frenar(velocidad);

    }

    public int calcularRevolucionesMotor(int fuerza, int radio) {

        return motor.calcularRevoluciones(fuerza, radio);

    }

    public int recomendarVelocidad(int velocidadViento) {

        return vela.recomendarVelocidad(velocidadViento);
    }

    public Vela getVela() {
        return vela;
    }
}

