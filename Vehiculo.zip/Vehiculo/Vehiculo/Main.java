package Vehiculo;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);



        System.out.print("ingrese la velocidad actual del Acuatico: ");

        int velocidadActualAcuatico = scanner.nextInt();

        System.out.print("ingrese la velocidad maxima del Acuatico: ");
        int velocidadMaximaAcuatico = scanner.nextInt();


        Motor motorAcuatico = new Motor(777, 7777);

        Vela velaAcuatico = new Vela(77, "Telaa");


        Acuatico vehiculoAcuatico = new Acuatico(velocidadActualAcuatico, velocidadMaximaAcuatico, motorAcuatico, velaAcuatico);


        System.out.print("ingrese el peso del Galeon: ");

        int pesoGaleon = scanner.nextInt();

        System.out.print("ingrese el nimero de velas del Galeon: ");

        int numeroDeVelasGaleon = scanner.nextInt();

        scanner.nextLine();

        System.out.print("ingrese el material del Galeon : ");

        String materialGaleon = scanner.nextLine();

        System.out.print("ingrese los años del Galeonn: ");

        int aniosGaleon = scanner.nextInt();

        Galeon galeon = new Galeon(10, 50, motorAcuatico, velaAcuatico, pesoGaleon, numeroDeVelasGaleon, materialGaleon, aniosGaleon);

        while (true) {
            System.out.println("Elija una opcio:");
            System.out.println("1. acelerar vehiculo terrestre");
            System.out.println("2. frenar vheiculo terrestre");
            System.out.println("3. calcular revoluciones del motor del vehiculo terrestre");
            System.out.println("4. acelerar el vehiculo Acuatico");
            System.out.println("5. frenar el vehiculo Acuatico");

            System.out.println("6. calcular revoluciones del motor del vehiculo Acuatico");
            System.out.println("7. Recomendar Velocidad para el vehiculo acuatyco");
            System.out.println("8. anclar Galeon");
            System.out.println("9. calcular velocidad total galeon");

            System.out.println("10. imprime info  del galeon");
            System.out.println("11. Sale");

            int opcion = scanner.nextInt();

            if (opcion == 11) {
                break;
            }

            switch (opcion) {
                case 1:

                    System.out.print("No hay vehiculo terrestre ");

                    break;
                case 2:
                    System.out.print("No hayy vehiculo terrestre ");

                    break;
                case 3:
                    System.out.print("No hay vehiculo terrestre ");

                    break;
                case 4:
                    System.out.print("ingrese la velocidad para acelerar el vehiculo Acuatico: ");

                    int velocidadAcelerarAcuatico = scanner.nextInt();
                    try {
                        vehiculoAcuatico.acelerar(velocidadAcelerarAcuatico);

                        vehiculoAcuatico.imprimir();
                    } catch (IllegalArgumentException e) {

                        System.out.println(e.getMessage());
                    }
                    break;
                case 5:
                    System.out.print("ingrese la velocidad para frenar el vehiculo Acuatico: ");

                    int velocidadFrenarAcuatico = scanner.nextInt();

                    try {
                        vehiculoAcuatico.frenar(velocidadFrenarAcuatico);


                        vehiculoAcuatico.imprimir();

                    } catch (IllegalArgumentException e) {
                        System.out.println(e.getMessage());

                    }
                    break;
                case 6:

                    System.out.print("El galeon claisco no tiene motor, depende la velas y el viento  ");

                    break;
                case 7:
                    System.out.print("iingrese la velocidad del viento para recomendar velocidad del Acuatico: ");
                    int velocidadViento = scanner.nextInt();

                    try {
                        int velocidadRecomendada = vehiculoAcuatico.recomendarVelocidad(velocidadViento);
                        System.out.println("veelocidad Recomendada con el Viento para el vehiculo (Acuatico): " + velocidadRecomendada);
                    } catch (IllegalArgumentException e) {

                        System.out.println(e.getMessage());
                    }
                    break;
                case 8:
                    galeon.anclar();
                    break;
                case 9:
                    System.out.print("Ingrese la velocidad del viento para calcular la velocidad total del Galeon: ");
                    int velocidadVientoGaleon = scanner.nextInt();

                    try {
                        int velocidadTotalGaleon = galeon.calcularVelocidadTotal(velocidadVientoGaleon);
                        System.out.println("Velocidad Total con el Viento (Galeon): " + velocidadTotalGaleon);

                    } catch (IllegalArgumentException e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 10:

                    galeon.imprimirInformacion();
                    break;

                default:
                    System.out.println("Opción no válida.");
                    break;
            }
        }

        scanner.close();
    }
}










