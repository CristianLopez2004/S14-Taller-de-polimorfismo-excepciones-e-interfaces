package Vehiculo;

public class Terrestre extends Vehiculo {


    public Terrestre(int velocidadActual, int velocidadMaxima) {


        super(velocidadActual, velocidadMaxima);
    }

    @Override
    public void acelerar(int velocidad) {

        super.acelerar(velocidad);
    }


    @Override
    public void frenar(int velocidad) {

        super.frenar(velocidad);
    }

    public int calcularRevolucionesMotor(int fuerza, int radio) {

        Motor motor = new Motor(167, 7777);

        return motor.calcularRevoluciones(fuerza, radio);
    }
}
