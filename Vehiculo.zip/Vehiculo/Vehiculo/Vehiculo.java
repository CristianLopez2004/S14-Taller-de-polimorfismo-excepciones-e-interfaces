package Vehiculo;


interface Conducible {
    void acelerar(int velocidad) throws IllegalArgumentException;
    void frenar(int velocidad) throws IllegalArgumentException;
}

public abstract class Vehiculo {

    private int velocidadActual;

    private int velocidadMaxima;


    public Vehiculo(int velocidadActual, int velocidadMaxima) {

        if (velocidadActual < 0 || velocidadMaxima <= 0 || velocidadActual > velocidadMaxima) {

            throw new IllegalArgumentException("velocidades mal puestass");
        }

        this.velocidadActual = velocidadActual;
        this.velocidadMaxima = velocidadMaxima;
    }

    public int getVelocidadActual() {
        return velocidadActual;
    }

    public int getVelocidadMaxima() {
        return velocidadMaxima;
    }

    public void imprimir() {
        System.out.println("Velocidad Actual del galeon: " + velocidadActual);

        System.out.println("Velocidad maxima del galeon: " + velocidadMaxima);
    }

    public void acelerar(int velocidad) {
        if (velocidad < 0) {
            throw new IllegalArgumentException("velocidad de aceleracion >=00");
        }
        if (velocidadActual + velocidad > velocidadMaxima) {

            velocidadActual = velocidadMaxima;

        } else {
            velocidadActual += velocidad;
        }
    }

    public void frenar(int velocidad) {
        if (velocidad < 0) {
            throw new IllegalArgumentException("velocidad de frenoo >=0");
        }
        if (velocidadActual - velocidad < 0) {

            velocidadActual = 0;

        } else {
            velocidadActual -= velocidad;
        }
    }
}