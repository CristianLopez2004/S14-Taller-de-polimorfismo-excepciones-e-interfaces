package Vehiculo;



public class Galeon extends Acuatico {

    private int peso;

    private int numeroDeVelas;

    private String material;
    private int anios;

    public Galeon(int velocidadActual, int velocidadMaxima, Motor motor, Vela vela, int peso, int numeroDeVelas, String material, int anios) {
        super(velocidadActual, velocidadMaxima, motor, vela);

        this.peso = peso;

        this.numeroDeVelas = numeroDeVelas;

        this.material = material;
        this.anios = anios;
    }

    public void anclar() {
        System.out.println("galon anclado");
    }

    public int calcularVelocidadTotal(int velocidadViento) {
        int velocidadRecomendada = 0;

        for (int i = 0; i < numeroDeVelas; i++) {

            velocidadRecomendada += getVela().recomendarVelocidad(velocidadViento);
        }
        return velocidadRecomendada;
    }

    public void imprimirInformacion() {

        System.out.println("Información del Galeón:");
        System.out.println("Peso: " + peso + " toneladas");

        System.out.println("Número de Velas: " + numeroDeVelas);
        System.out.println("Material: " + material);

        System.out.println("Años: " + anios);
    }
}


