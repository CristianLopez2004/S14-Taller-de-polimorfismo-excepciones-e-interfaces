package Vehiculo;

public class Vela {


    private int superficie;

    private String material;


    public Vela(int superficie, String material) {

        this.superficie = superficie;

        this.material = material;
    }

    public int getSuperficie() {

        return superficie;
    }

    public String getMaterial() {
        return material;
    }

    public int recomendarVelocidad(int velocidadViento) {

        if (velocidadViento <= 0) {

            throw new IllegalArgumentException("velocidad de vientoo >0");
        }
        return velocidadViento / 4;
    }
}

